# Description

The resource is responsible for ensuring that a MSU
(Standalone Windows Update) is installed.
